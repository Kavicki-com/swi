import React, { forwardRef, useState } from 'react';
import { type View } from 'react-native';
import { elevation } from '../../tokens';
import {
  Badge,
  BadgeText,
  Container,
  HoverOverlay,
  IconSlot,
  Label,
  PressedOverlay,
} from './Button.styles';
import { Tooltip } from '../Tooltip';
import type { ButtonProps } from './Button.types';

export const Button = forwardRef<View, ButtonProps>(
  (
    {
      label,
      variant = 'contained',
      size = 'default',
      shape = 'rounded',
      diameter,
      elevation: elevationProp = 'sm',
      backgroundColor,
      borderColor,
      borderWidth,
      labelColor,
      // Figma spec usa Inter Bold pros labels em todas as telas inspecionadas
      // (login, sign-up, complimentary-data, smartband). Mantém Montserrat
      // disponível via prop explícita `labelFamily="title"`.
      labelFamily = 'body',
      labelWeight = 'bold',
      iconLeft,
      iconRight,
      disabled: disabledProp = false,
      fullWidth = false,
      underline = false,
      onPress,
      onLongPress,
      accessibilityLabel,
      accessibilityHint,
      testID,
      badge,
      tooltip,
      tooltipSide,
    },
    ref,
  ) => {
    const [hovered, setHovered] = useState(false);
    const [pressed, setPressed] = useState(false);

    const disabled = disabledProp ?? false;
    const showDropShadow =
      variant === 'contained' && !disabled && !pressed && elevationProp !== 'none';
    const shadowStyle =
      elevationProp === 'none' ? undefined : elevation[elevationProp as 'sm' | 'md' | 'lg'];
    const showHoverOverlay = variant === 'contained' && hovered && !pressed && !disabled;
    const showPressedOverlay = pressed && !disabled;
    const hasLabel = typeof label === 'string' && label.length > 0;
    const hasBadge = typeof badge === 'string' && badge.length > 0;

    const button = (
      <Container
        ref={ref}
        $variant={variant}
        $size={size}
        $shape={shape}
        $diameter={diameter}
        $backgroundColor={backgroundColor}
        $borderColor={borderColor}
        $borderWidth={borderWidth}
        $hovered={hovered}
        $pressed={pressed}
        $disabled={disabled}
        $fullWidth={fullWidth}
        style={showDropShadow ? shadowStyle : undefined}
        disabled={disabled}
        onPress={disabled ? undefined : onPress}
        onLongPress={disabled ? undefined : onLongPress}
        onPressIn={() => setPressed(true)}
        onPressOut={() => setPressed(false)}
        onHoverIn={() => setHovered(true)}
        onHoverOut={() => setHovered(false)}
        accessibilityRole="button"
        accessibilityState={{ disabled }}
        accessibilityLabel={
          accessibilityLabel ?? (hasBadge ? [label, badge].filter(Boolean).join(', ') : label)
        }
        accessibilityHint={accessibilityHint}
        testID={testID}
      >
        {iconLeft ? <IconSlot>{iconLeft}</IconSlot> : null}
        {hasLabel ? (
          <Label
            $variant={variant}
            $hovered={hovered}
            $disabled={disabled}
            $underline={underline}
            $labelColor={labelColor}
            $labelFamily={labelFamily}
            $labelWeight={labelWeight}
            numberOfLines={1}
          >
            {label}
          </Label>
        ) : null}
        {iconRight ? <IconSlot>{iconRight}</IconSlot> : null}
        {showHoverOverlay ? <HoverOverlay $shape={shape} /> : null}
        {showPressedOverlay ? (
          <PressedOverlay $shape={shape} style={elevation.negative} />
        ) : null}
        {hasBadge ? (
          <Badge accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
            <BadgeText numberOfLines={1}>{badge}</BadgeText>
          </Badge>
        ) : null}
      </Container>
    );

    return tooltip ? (
      <Tooltip label={tooltip} side={tooltipSide}>
        {button}
      </Tooltip>
    ) : (
      button
    );
  },
);

Button.displayName = 'Button';
