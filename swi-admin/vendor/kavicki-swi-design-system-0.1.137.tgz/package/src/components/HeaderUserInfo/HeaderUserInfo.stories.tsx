import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Text, View } from 'react-native';
import { useTheme } from '../../theme';
import { HeaderUserInfo } from './HeaderUserInfo';

const AVATAR = 'https://i.pravatar.cc/200?img=12';

const meta: Meta<typeof HeaderUserInfo> = {
  title: 'Components/HeaderUserInfo',
  component: HeaderUserInfo,
  args: {
    bpm: 99,
    pressure: '12/8',
    progress: 50,
    avatarUri: AVATAR,
    bpmUnit: 'bpm',
  },
  argTypes: {
    bpm: { control: { type: 'number', min: 0, max: 250 } },
    pressure: { control: 'text' },
    progress: { control: { type: 'range', min: 0, max: 100, step: 1 } },
    avatarUri: { control: 'text' },
    bpmUnit: { control: 'text' },
  },
};

export default meta;
type Story = StoryObj<typeof HeaderUserInfo>;

const Caption = ({ children }: { children: string }) => (
  <Text
    style={{
      fontFamily: 'Inter, system-ui, sans-serif',
      fontSize: 11,
      letterSpacing: 1,
      textTransform: 'uppercase',
      color: '#9F9F9F',
    }}
  >
    {children}
  </Text>
);

export const Playground: Story = {};

export const Default: Story = {};

export const LowProgress: Story = { args: { progress: 15 } };
export const HighProgress: Story = { args: { progress: 90 } };
export const HighBpm: Story = { args: { bpm: 142, pressure: '14/9', progress: 80 } };
/** Sem aparelho pareado: "--" nos vitais e barra vazia. */
export const NoReading: Story = {
  name: 'Sem leitura',
  args: { bpm: null, pressure: null, progress: null },
};
export const NoAvatar: Story = { args: { avatarUri: undefined } };

// Sem foto, as iniciais do nome, como em Configurações.
export const InitialsWithoutPhoto: Story = {
  name: 'Iniciais sem foto',
  args: { avatarUri: undefined, name: 'Ana Clara Mendonça' },
};

export const FigmaIcons: Story = {
  name: 'Figma icons (heart_filled + vitals_pulse)',
  args: {
    heartIconName: 'heart_filled',
    pressureIconName: 'vitals_pulse',
  },
};

export const NoBorder: Story = {
  name: 'No avatar border',
  args: { bordered: false },
};

export const BorderMatchesDarkBg: Story = {
  name: 'Border matches dark bg (invisible ring)',
  parameters: { controls: { disable: true }, actions: { disable: true } },
  render: () => {
    const theme = useTheme();
    return (
      <View style={{ padding: 24, backgroundColor: theme.background }}>
        <HeaderUserInfo
          bpm={99}
          pressure="12/8"
          progress={50}
          avatarUri={AVATAR}
          heartIconName="heart_filled"
          pressureIconName="vitals_pulse"
          borderColor={theme.background}
        />
      </View>
    );
  },
};

export const Overview: Story = {
  name: 'Overview — varied vitals',
  parameters: { controls: { disable: true }, actions: { disable: true } },
  render: () => (
    <View style={{ gap: 24, alignItems: 'flex-start' }}>
      <View style={{ gap: 6 }}>
        <Caption>resting — bpm 72, pressure 12/8</Caption>
        <HeaderUserInfo bpm={72} pressure="12/8" progress={30} avatarUri={AVATAR} />
      </View>
      <View style={{ gap: 6 }}>
        <Caption>active — bpm 99, pressure 13/8</Caption>
        <HeaderUserInfo bpm={99} pressure="13/8" progress={55} avatarUri={AVATAR} />
      </View>
      <View style={{ gap: 6 }}>
        <Caption>peak — bpm 142, pressure 14/9</Caption>
        <HeaderUserInfo bpm={142} pressure="14/9" progress={92} avatarUri={AVATAR} />
      </View>
      <View style={{ gap: 6 }}>
        <Caption>no avatar</Caption>
        <HeaderUserInfo bpm={88} pressure="12/8" progress={40} />
      </View>
    </View>
  ),
};
