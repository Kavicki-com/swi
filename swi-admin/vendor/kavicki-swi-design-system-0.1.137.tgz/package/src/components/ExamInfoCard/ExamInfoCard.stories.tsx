import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Text, View } from 'react-native';
import { ExamInfoCard } from './ExamInfoCard';

const meta: Meta<typeof ExamInfoCard> = {
  title: 'Components/ExamInfoCard',
  component: ExamInfoCard,
  args: {
    year: 2025,
    date: '12 Ago',
    examName: 'Exame admissional',
    actionLabel: 'Baixar exame',
    actionDisabled: false,
    fullWidth: true,
  },
  argTypes: {
    year: { control: 'text' },
    date: { control: 'text' },
    examName: { control: 'text' },
    actionLabel: { control: 'text' },
    actionDisabled: { control: 'boolean' },
    fullWidth: { control: 'boolean' },
    onExamPress: { action: 'examPress' },
    onActionPress: { action: 'actionPress' },
  },
  parameters: { layout: 'padded' },
};

export default meta;
type Story = StoryObj<typeof ExamInfoCard>;

const Caption = ({ children }: { children: string }) => (
  <Text
    style={{
      fontFamily: 'Inter, system-ui, sans-serif',
      fontSize: 11,
      letterSpacing: 1,
      textTransform: 'uppercase',
      color: '#9F9F9F',
    }}
  >
    {children}
  </Text>
);

export const Playground: Story = {};

export const Default: Story = {};

export const Periodic: Story = {
  args: { year: 2024, date: '03 Mar', examName: 'Exame periódico' },
};

export const Demissional: Story = {
  args: { year: 2023, date: '28 Nov', examName: 'Exame demissional' },
};

export const DisabledAction: Story = {
  args: { actionDisabled: true },
};

export const Mobile: Story = {
  args: { fullWidth: true },
  parameters: { viewport: { defaultViewport: 'iphone14' } },
};

export const Stacked: Story = {
  name: 'Stacked — list of exams',
  parameters: { controls: { disable: true }, actions: { disable: true } },
  render: () => (
    <View style={{ gap: 8 }}>
      <Caption>Histórico de exames</Caption>
      <ExamInfoCard year={2025} date="12 Ago" examName="Exame admissional" fullWidth />
      <ExamInfoCard year={2024} date="03 Mar" examName="Exame periódico" fullWidth />
      <ExamInfoCard year={2023} date="28 Nov" examName="Exame demissional" fullWidth />
    </View>
  ),
};

export const Compact: Story = {
  name: 'Compact — sidebar row',
  args: {
    year: 2027,
    date: '05 Mar',
    examName: 'Exame de reciclagem técnica',
    compact: true,
    fullWidth: true,
  },
};

export const CompactStacked: Story = {
  name: 'Compact — admin profile history',
  parameters: { controls: { disable: true }, actions: { disable: true } },
  render: () => (
    <View style={{ width: 300, gap: 8 }}>
      <Caption>Histórico de exames</Caption>
      <ExamInfoCard
        year={2027}
        date="05 Mar"
        examName="Exame de reciclagem técnica"
        compact
        fullWidth
      />
      <ExamInfoCard
        year={2029}
        date="19 Nov"
        examName="Avaliação de segurança"
        compact
        fullWidth
      />
      <ExamInfoCard
        year={2031}
        date="14 Jul"
        examName="Certificação em normas ISO"
        compact
        fullWidth
      />
    </View>
  ),
};

export const CompactMobile: Story = {
  name: 'Compact mobile — Figma 342:9907 + 361:12377',
  parameters: { controls: { disable: true }, actions: { disable: true } },
  render: () => (
    <View style={{ width: 328, gap: 16 }}>
      <Caption>Histórico Médico</Caption>
      <ExamInfoCard
        year={2027}
        date="05 Mar"
        examName="Exame de reciclagem técnica"
        compact
        mobile
        fullWidth
      />
      <ExamInfoCard
        year={2029}
        date="19 Nov"
        examName="Avaliação de segurança"
        compact
        mobile
        fullWidth
      />
      <ExamInfoCard
        year={2031}
        date="14 Jul"
        examName="Certificação em normas ISO"
        compact
        mobile
        fullWidth
      />
      <ExamInfoCard
        year={2033}
        date="28 Fev"
        examName="Exame de aptidão física e mental"
        compact
        mobile
        future
        fullWidth
      />
    </View>
  ),
};

// v0.1.137: cluster de ações (visualizar, baixar, excluir) no lugar do botão
// único, para os exames do cadastro de usuário.
export const WithActions: Story = {
  name: 'Ações (visualizar, baixar, excluir)',
  args: {
    year: 2027,
    date: '05 Mar',
    examName: 'Exame admissional',
    compact: true,
    fullWidth: true,
    actions: ['view', 'download', 'remove'],
    onView: () => {},
    onDownload: () => {},
    onRemove: () => {},
  },
};

// Exame escolhido mas ainda não enviado (cadastro novo): dá para visualizar e
// excluir, mas não baixar (não subiu).
export const PendingActions: Story = {
  name: 'Ações do pendente (sem baixar)',
  args: {
    year: 2027,
    date: '05 Mar',
    examName: 'Exame admissional (pendente)',
    compact: true,
    fullWidth: true,
    actions: ['view', 'remove'],
    onView: () => {},
    onRemove: () => {},
  },
};
